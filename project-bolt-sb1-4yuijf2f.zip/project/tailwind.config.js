/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eefbf8',
          100: '#d6f5eb',
          200: '#b0e9d7',
          300: '#7dd8bd',
          400: '#43bd9c',
          500: '#10a37f', // ChatGPT primary green
          600: '#0d8165',
          700: '#0f6954',
          800: '#115445',
          900: '#11463b',
          950: '#07271f',
        },
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            code: {
              color: theme('colors.gray.800'),
              backgroundColor: theme('colors.gray.100'),
              borderRadius: theme('borderRadius.md'),
              padding: `${theme('spacing[0.5]')} ${theme('spacing[1]')}`,
            },
            'code::before': {
              content: '""',
            },
            'code::after': {
              content: '""',
            },
          },
        },
        invert: {
          css: {
            code: {
              color: theme('colors.gray.200'),
              backgroundColor: theme('colors.gray.800'),
            },
          },
        },
      }),
    },
  },
  plugins: [],
};