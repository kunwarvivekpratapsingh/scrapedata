export type Role = 'user' | 'assistant' | 'system';

export interface MessageType {
  id: string;
  content: string;
  role: Role;
  timestamp: string;
}