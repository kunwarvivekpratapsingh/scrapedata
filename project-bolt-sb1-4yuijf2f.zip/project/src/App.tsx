import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import { MessageType } from './types';
import { generateUniqueId } from './utils';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [conversations, setConversations] = useState<{ id: string; title: string; messages: MessageType[] }[]>([
    {
      id: generateUniqueId(),
      title: 'New chat',
      messages: [],
    },
  ]);
  const [activeConversationId, setActiveConversationId] = useState<string>(conversations[0].id);
  const [isDarkMode, setIsDarkMode] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const createNewConversation = () => {
    const newConversation = {
      id: generateUniqueId(),
      title: 'New chat',
      messages: [],
    };
    setConversations([newConversation, ...conversations]);
    setActiveConversationId(newConversation.id);
  };

  const deleteConversation = (id: string) => {
    const updatedConversations = conversations.filter((conv) => conv.id !== id);
    setConversations(updatedConversations);
    
    if (id === activeConversationId && updatedConversations.length > 0) {
      setActiveConversationId(updatedConversations[0].id);
    } else if (updatedConversations.length === 0) {
      createNewConversation();
    }
  };

  const sendMessage = (message: string) => {
    if (!message.trim()) return;
    
    const userMessage: MessageType = {
      id: generateUniqueId(),
      content: message,
      role: 'user',
      timestamp: new Date().toISOString(),
    };
    
    const aiMessage: MessageType = {
      id: generateUniqueId(),
      content: `This is a simulated response to: "${message}"`,
      role: 'assistant',
      timestamp: new Date().toISOString(),
    };
    
    const updatedConversations = conversations.map((conv) => {
      if (conv.id === activeConversationId) {
        // Update conversation title based on first user message if title is default
        const updatedTitle = conv.title === 'New chat' && conv.messages.length === 0
          ? message.slice(0, 30) + (message.length > 30 ? '...' : '')
          : conv.title;
        
        return {
          ...conv,
          title: updatedTitle,
          messages: [...conv.messages, userMessage, aiMessage],
        };
      }
      return conv;
    });
    
    setConversations(updatedConversations);
  };

  const activeConversation = conversations.find((conv) => conv.id === activeConversationId) || conversations[0];

  return (
    <div className={`h-screen flex flex-col ${isDarkMode ? 'dark' : ''}`}>
      <div className="flex h-full overflow-hidden bg-white dark:bg-[#343541]">
        <Sidebar
          isSidebarOpen={isSidebarOpen}
          toggleSidebar={toggleSidebar}
          conversations={conversations}
          activeConversationId={activeConversationId}
          setActiveConversationId={setActiveConversationId}
          createNewConversation={createNewConversation}
          deleteConversation={deleteConversation}
          isDarkMode={isDarkMode}
          toggleDarkMode={toggleDarkMode}
        />
        <ChatArea
          conversation={activeConversation}
          sendMessage={sendMessage}
          isSidebarOpen={isSidebarOpen}
          toggleSidebar={toggleSidebar}
        />
      </div>
    </div>
  );
}

export default App;