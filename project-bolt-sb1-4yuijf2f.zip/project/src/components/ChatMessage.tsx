import React from 'react';
import { MessageType } from '../types';
import { formatDate } from '../utils';

interface ChatMessageProps {
  message: MessageType;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isAssistant = message.role === 'assistant';

  return (
    <div className={`flex ${isAssistant ? 'bg-gray-50 dark:bg-[#444654]' : ''} py-4 -mx-4 px-4`}>
      <div className="flex-1 max-w-4xl mx-auto flex">
        {/* Avatar */}
        <div className="flex-shrink-0 mr-4">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            isAssistant ? 'bg-[#10a37f] text-white' : 'bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-gray-200'
          }`}>
            {isAssistant ? 'AI' : 'U'}
          </div>
        </div>
        
        {/* Message content */}
        <div className="flex-1">
          <div className="flex items-center mb-1">
            <h3 className="font-medium text-gray-900 dark:text-gray-100">
              {isAssistant ? 'ChatGPT' : 'You'}
            </h3>
            <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">
              {formatDate(message.timestamp)}
            </span>
          </div>
          <div className="prose dark:prose-invert prose-sm max-w-none text-gray-800 dark:text-gray-200">
            {message.content.split('\n').map((line, i) => (
              <React.Fragment key={i}>
                {line}
                {i < message.content.split('\n').length - 1 && <br />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;