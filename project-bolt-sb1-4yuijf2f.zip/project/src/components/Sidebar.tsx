import React from 'react';
import { MessageType } from '../types';
import { Menu, X, Plus, MessageSquare, Sun, Moon, Trash2 } from 'lucide-react';

interface SidebarProps {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  conversations: { id: string; title: string; messages: MessageType[] }[];
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  createNewConversation: () => void;
  deleteConversation: (id: string) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  isSidebarOpen,
  toggleSidebar,
  conversations,
  activeConversationId,
  setActiveConversationId,
  createNewConversation,
  deleteConversation,
  isDarkMode,
  toggleDarkMode,
}) => {
  if (!isSidebarOpen) {
    return (
      <div className="fixed top-0 left-0 z-10 p-2 bg-white dark:bg-[#202123] rounded-br-md shadow-md">
        <button 
          onClick={toggleSidebar}
          className="p-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
          aria-label="Open sidebar"
        >
          <Menu size={24} />
        </button>
      </div>
    );
  }

  return (
    <div className="w-64 flex-shrink-0 h-full flex flex-col bg-[#f7f7f8] dark:bg-[#202123] border-r border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={createNewConversation}
          className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 rounded-md border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
        >
          <Plus size={16} /> New chat
        </button>
        <button
          onClick={toggleSidebar}
          className="p-2 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-md"
          aria-label="Close sidebar"
        >
          <X size={18} />
        </button>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto py-2 px-2 space-y-1">
        {conversations.map((conversation) => (
          <div
            key={conversation.id}
            className={`group flex items-center justify-between px-3 py-2 rounded-md cursor-pointer ${
              activeConversationId === conversation.id
                ? 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white'
                : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            onClick={() => setActiveConversationId(conversation.id)}
          >
            <div className="flex items-center gap-2 truncate">
              <MessageSquare size={16} />
              <span className="truncate">{conversation.title || 'New chat'}</span>
            </div>
            {activeConversationId === conversation.id && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteConversation(conversation.id);
                }}
                className="opacity-0 group-hover:opacity-100 p-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                aria-label="Delete conversation"
              >
                <Trash2 size={16} />
              </button>
            )}
          </div>
        ))}
        {conversations.length === 0 && (
          <div className="px-3 py-2 text-sm text-gray-500 dark:text-gray-400">
            No conversations yet
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <button
          onClick={toggleDarkMode}
          className="flex items-center gap-2 px-3 py-2 w-full text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md transition-colors"
        >
          {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
          <span>{isDarkMode ? 'Light mode' : 'Dark mode'}</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;