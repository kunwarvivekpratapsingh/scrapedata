import React, { useState, useRef, useEffect } from 'react';
import { MessageType } from '../types';
import { Menu, Send } from 'lucide-react';
import ChatMessage from './ChatMessage';

interface ChatAreaProps {
  conversation: { id: string; title: string; messages: MessageType[] };
  sendMessage: (message: string) => void;
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
}

const ChatArea: React.FC<ChatAreaProps> = ({
  conversation,
  sendMessage,
  isSidebarOpen,
  toggleSidebar,
}) => {
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation.messages]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [inputValue]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      sendMessage(inputValue);
      setInputValue('');
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-white dark:bg-[#343541] overflow-hidden">
      {/* Chat Header (Mobile only) */}
      {!isSidebarOpen && (
        <div className="lg:hidden p-4 border-b border-gray-200 dark:border-gray-700 flex items-center">
          <button
            onClick={toggleSidebar}
            className="p-2 mr-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md"
            aria-label="Open sidebar"
          >
            <Menu size={20} />
          </button>
          <h2 className="text-lg font-medium text-gray-800 dark:text-gray-200 truncate">
            {conversation.title}
          </h2>
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {conversation.messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">
              ChatGPT
            </h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-md">
              How can I help you today?
            </p>
          </div>
        ) : (
          conversation.messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-gray-200 dark:border-gray-700 p-4">
        <form onSubmit={handleSubmit} className="relative max-w-4xl mx-auto">
          <textarea
            ref={textareaRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Message ChatGPT..."
            className="w-full p-3 pr-12 bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg border border-gray-300 dark:border-gray-600 focus:outline-none focus:border-blue-500 dark:focus:border-blue-400 resize-none overflow-hidden min-h-[50px] max-h-36"
            rows={1}
          />
          <button
            type="submit"
            disabled={!inputValue.trim()}
            className={`absolute right-3 bottom-3 p-1.5 rounded-md ${
              inputValue.trim()
                ? 'text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600'
                : 'text-gray-400 dark:text-gray-500 cursor-not-allowed'
            }`}
          >
            <Send size={20} />
          </button>
        </form>
        <p className="text-xs text-center mt-2 text-gray-500 dark:text-gray-400">
          ChatGPT can make mistakes. Consider checking important information.
        </p>
      </div>
    </div>
  );
};

export default ChatArea;